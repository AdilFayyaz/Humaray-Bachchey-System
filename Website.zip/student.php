<!DOCTYPE HTML>
<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
h3{
	font-size: 25px;
	color:white;
}
select {
   background-color: thistle;  
    box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);
    color: #555;
	max-width : 10%;
}
select:hover{
		border: dashed purple;
}

.bg-contact2 {
  width: 100%;  
  background-repeat: repeat;
  background-position: center center;
  background-size: cover;
  background-opacity: 30%;
}

.sidenav {
  height: 100%;
  width: 15.5%;
  position: fixed;
  z-index: 1;
  top: 15%;
  left: 84%;
  background-color: thistle;
  overflow-x: hidden;
  padding-top: 17px;
   box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.3), 0 5px 5px 0 rgba(0, 0, 0, 0.5);
}

.sidenav a {
  padding: 0px 0px 0px 0px;
  text-decoration: none;
  font-family: "Lato", sans-serif;
  font-size: 20px;
  color: #611f72;
  display: block;
  text-align: center;
}

.sidenav a:hover {
  color: thistle;
  background-color: #611f72;
}

.main {
  margin-right: 20% ; /* Same as the width of the sidenav */
  margin-left: 2%;
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 150px 0px;
  color = white;
  height: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
input[type=text2] {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  background-color: white;
  color: black;
}
input[type=text2]:focus {
  background-color: thistle;
}
input[type=text2]:hover {
  background-color: thistle;
}

#classes-button {
   background-color: thistle ;
   border: none;
   font-family: "Lato", sans-serif;
   font-size: 28px;
   color: #611f72;
   padding: 28px 65px;
   margin: 10px 0px;
   cursor: pointer;
}
#classes-button:hover{
  color: thistle;
  background-color: #611f72;
  text-align = center;
}
#nameid-button {
   background-color: thistle ;
   border: none;
   font-family: "Lato", sans-serif;
   font-size: 20px;
   color: #611f72;
   padding: 10px 50px;
   margin: 0px 0px;
   cursor: pointer;
}
#nameid-button:hover{
  color: thistle;
  background-color: #611f72;
  text-align = center;
}
#search-button {
  background-color:#611f72 ;
  color: white;
  padding: 12px 0px;
  border: none;
  cursor: pointer;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  border-radius: 12px;
}
#search-button:hover{
  background-color:thistle ;
}

.btn {
  background-color: transparent;
  border: none;
  color: purple;
  padding: 10px 15px;
  font-size: 30px;
  cursor: cursor;
}
.btn-right{
  float:right;
  background-color: transparent;
  border: none;
  color: purple;
  padding: 3px 3px;
  font-size: 26px;
  cursor: cursor;
  border: 2px solid black;
  border-color : purple;
}
/* Darker background on mouse-over */
.btn:hover {
  background-color: purple;
  color: white;
}
.btn-right:hover {
  background-color: purple;
  color: white;
}
</style>
	<head>
		<meta charset ="UTF-8">
	<title>Humaray Bachchay NGO</title>
	<link href="layout.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<nav id="navigation-bar" style="z-index: 9;">
		<img id="logo" src="logo.png">
		<span class="navbar-text text" style= "margin-top: 30px;"> HUMARAY BACHCHAY  </span>
		<a href="Home.html"><p class="impact">Get in Touch</p></a>
		<div class="dropdown">
			<p class="impact">Parents/Guardians</p>
			<div class="dropdown-content">
			<a href="Std_Admission.php">Student Admission Form</a>
			<a href="Std_Acc_Form.php">Student Accompanying Form</a>
			<a href="Assignment_Form.php">Class Assignment Form</a>
			<a href="available_courses.php">Available Courses</a>
			<a href="Update_Info.php">Update Information</a>
			</div>
		</div> 
		<a href="Student.html"><p class="impact">Students</p></a>
		<div class="dropdown">
			<p class="impact">Staff</p>
			<div class="dropdown-content">
			<a href="Reports.php">Reports</a>
			<a href="student.php">Students Per Class</a>
			<a href="edit.php">Edit Sudents</a>
			</div>
		</div>
		<a href="Home.html"><p class="impact">About</p></a>
		<a href="Home.html"><p class="impact">Home</p></a>
	</nav>
	

	<div class="sidenav">
		<form action="" method = "post">
		<a href="#Class1"><input type="submit" id = "classes-button" name = "choice" value="CLASS 1" /></a>
		<a href="#Class2"><input type="submit" id = "classes-button" name = "choice" value="CLASS 2"/></a>
		<a href="#Class3"><input type="submit" id = "classes-button" name = "choice" value="CLASS 3"/></a>
		<a href="#Class4"><input type="submit" id = "classes-button" name = "choice" value="CLASS 4"/></a>
		<a href="#Class5"><input type="submit" id = "classes-button" name = "choice" value="CLASS 5"/></a>
		<a href="#Class6"><input type="submit" id = "classes-button" name = "choice" value="CLASS 6"/></a>
		</form>
	</div>
	<div class="bg-contact2" style="background-image: url('bgnew.jpg')">
	<div class="main" >
		<form action="" method = "get"> 
			 <h3>Enter Student Information: <input type="text2" name="stdid"/>
				<select name = "srch">
				<option value = "id"> ID </option>
				<option	value = "name"> NAME </option>
				</select>
			</h3>
			<button name = "actionn1" type = "submit" class="btn"><i class="fa fa-search"></i></button>
			<a href = "edit.php"  type = "submit" class="btn"><i class="fa fa-edit"></i></a>
			<button name = "actionn4" type = "submit" class="btn"><i class="fa fa-trash"></i></button>
			<right><a href = "enroll.php" type = "submit" class="btn-right"><i class="fa fa-plus"> [ADD] </i></a></right>
		<form>
	</div>
	</div>
	</body>
	
<?php
			$db_sid = "(DESCRIPTION =
		(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
		(CONNECT_DATA =
		  (SERVER = DEDICATED)
		  (SERVICE_NAME = orcl)
		)
	  )";
			$db_user = "scott";   // Oracle username e.g "scott"
			$db_pass = "1234";    // Password for user e.g "1234"
			$con = oci_connect($db_user,$db_pass,$db_sid); 
			if($con) 
				{ } 
			else 
				{ die('Could not connect to Oracle: '); } 
			
		if(isset($_POST["choice"])){
			echo "<br>";
			$choice = $_POST["choice"];
			if($choice == 'CLASS 1'){
					$choice = 1;
			}
			else if($choice == 'CLASS 2'){
					$choice = 2;
			}
			else if($choice == 'CLASS 3'){
					$choice = 3;
			}
			else if($choice == 'CLASS 4'){
					$choice = 4;
			}
			else if($choice == 'CLASS 5'){
					$choice = 5;
			}
			else if($choice == 'CLASS 6'){
					$choice = 6;
			}
				
			$q = "select COUNT(Enrolled) as C from Enrollment_History 
					where enrolled = 1 and class_id=".$choice;
					$query_id = oci_parse($con, $q);
					$runselect = oci_execute($query_id);
					$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
			$totalst = $arr[0];
			$q = "select COUNT(gender) as C from Enrollment_History h , student s
					where enrolled = 1 and gender = 'M' and s.student_id = h.student_id and class_id=".$choice;
					$query_id = oci_parse($con, $q);
					$runselect = oci_execute($query_id);
					$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
			$totalboys = $arr[0];
			$q = "select COUNT(gender) as C from Enrollment_History h , student s
					where enrolled = 1 and gender = 'F' and s.student_id = h.student_id and class_id=".$choice;
					$query_id = oci_parse($con, $q);
					$runselect = oci_execute($query_id);
					$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
			$totalgirls = $arr[0];
			echo '<div style="font-size:25px ;color:purple ; text-decoration: underline #611f72"> GENERAL STATISTICS </div>';
			echo "<font size='4.5' face='Sans Serif' color = 'silver'>";
			echo "TOTAL STUDENTS IN CLASS:&nbsp&nbsp".$totalst."<br>";
			echo "TOTAL BOYS IN CLASS:&nbsp&nbsp".$totalboys."<br>";
			echo "TOTAL GIRLS IN CLASS:&nbsp&nbsp".$totalgirls."<br>";
			?>
			<hr><br><br>
			<?php	
				//SECTION BL-G ---->
				$q = "select COUNT(Enrolled) as C from Enrollment_History 
					where section_id = 'BL-G' and enrolled = 1 and class_id=".$choice;
					$query_id = oci_parse($con, $q);
					$runselect = oci_execute($query_id);
					$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
				
				echo '<div style="font-size:30px ;color:#611f72 ; text-decoration: underline #611f72">CLASS '.$choice.' [BL-G]:   '.$arr[0].' </div>';
				if($arr[0] != 0){
				$q= "select s.Student_ID, s.Name, s.Gender, round(months_between(sysdate, s.dob)/12,2) from Student s, Enrollment_History e
					where e.Student_ID = s.Student_ID and e.enrolled = 1 and e.section_id = 'BL-G' and e.class_id= " .$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				echo "<br>";
				
				while($arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "STUDENT ID:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[0];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspNAME:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[1];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspGENDER:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[2];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspAGE:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[3];
					echo "<br>";
				}
				}
				else { 
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "<br>--------------- NO STUDENTS IN THE SECTION ---------------<br> ";
				}
				echo "<br>";
				
				//SECTION GR-B ---->
				$q = "select COUNT(Enrolled) as C from Enrollment_History 
					where section_id = 'GR-B' and enrolled = 1 and class_id=".$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
				
				echo '<div style="font-size:30px ;color:#611f72 ; text-decoration: underline #611f72">CLASS '.$choice.' [GR-B]:   '.$arr[0].' </div>';
				if($arr[0] != 0){
				$q= "select s.Student_ID, s.Name, s.Gender, round(months_between(sysdate, s.dob)/12,2) from Student s, Enrollment_History e
					where e.Student_ID = s.Student_ID and e.enrolled = 1 and e.section_id = 'GR-B' and e.class_id= " .$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				echo "<br>";
				
				while($arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "STUDENT ID:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[0];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspNAME:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[1];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspGENDER:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[2];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspAGE:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[3];
					echo "<br>";
				}
				}
				else { 
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "<br>--------------- NO STUDENTS IN THE SECTION ---------------<br> ";
				}
				echo "<br>";
				
				//SECTION YW-G ---->
				$q = "select COUNT(Enrolled) as C from Enrollment_History 
					where section_id = 'YW-G' and enrolled = 1 and class_id=".$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
				
				echo '<div style="font-size:30px ;color:#611f72 ; text-decoration: underline #611f72">CLASS '.$choice.' [YW-G]:   '.$arr[0].' </div>';
				if($arr[0] != 0){
				$q= "select s.Student_ID, s.Name, s.Gender, round(months_between(sysdate, s.dob)/12,2) from Student s, Enrollment_History e
					where e.Student_ID = s.Student_ID and e.enrolled = 1 and e.section_id = 'YW-G' and e.class_id= " .$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				echo "<br>";
				
				while($arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "STUDENT ID:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[0];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspNAME:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[1];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspGENDER:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[2];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspAGE:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[3];
					echo "<br>";
				}
				}
				else { 
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "<br>--------------- NO STUDENTS IN THE SECTION --------------- <br>";
				}
				echo "<br>";
				
				//SECTION YW-B ---->
				$q = "select COUNT(Enrolled) as C from Enrollment_History 
					where section_id = 'YW-B' and enrolled = 1 and class_id=".$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				$arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
				
				echo '<div style="font-size:30px ;color:#611f72 ; text-decoration: underline #611f72">CLASS '.$choice.' [YW-B]:   '.$arr[0].' </div>';
				if($arr[0] != 0){
				$q= "select s.Student_ID, s.Name, s.Gender, round(months_between(sysdate, s.dob)/12,2) from Student s, Enrollment_History e
					where e.Student_ID = s.Student_ID and e.enrolled = 1 and e.section_id = 'YW-B' and e.class_id= " .$choice;
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				echo "<br>";
				
				while($arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "STUDENT ID:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[0];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspNAME:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[1];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspGENDER:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[2];
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "&nbsp&nbsp&nbsp&nbspAGE:&nbsp&nbsp";
					echo "<font size='5' face='Sans Serif' color = 'dimgrey'>";
					echo $arr[3];
					echo "<br>";
				}
				}
				else { 
					echo "<font size='5' face='Sans Serif' color = 'silver'>";
					echo "<br>--------------- NO STUDENTS IN THE SECTION ---------------<br> ";
				}
				echo "<br>";
		}
		if(isset($_GET["actionn1"])){
				echo "<br>";
				$srch = $_GET["srch"];
				$std_id = $_GET["stdid"]; 
				if($srch == "id"){
					$q = " select student_ID, name, gender, round(months_between(sysdate, DOB)/12,1)age from student where student_id ='".$std_id."'";
				}
				else if($srch == "name"){
					$q = " select student_ID, name, gender, round(months_between(sysdate, DOB)/12,1)age from student where name ='".$std_id."'";	
				}
				$query_id = oci_parse($con, $q);
				$r = oci_execute($query_id); 
				$row = oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS);
				if($row){
					echo '<div style="font-size:30px ;color:purple ; text-decoration: underline purple">RESULTS:<br> </div>';
					echo "<font size='4' face='Arial' color = 'purple'>";
					echo "Student_ID: ".$row['STUDENT_ID']."&nbsp&nbsp&nbsp&nbsp&nbsp&nbspName: ".$row['NAME'];
					echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbspGender: ".$row['GENDER']."&nbsp&nbsp&nbsp&nbsp&nbsp&nbspAge: ".$row['AGE'];
					echo "<br>";
				}
				else{
					echo '<div style="font-size:30px ;color:purple ; text-decoration: underline purple">RESULTS:<br> </div>';
					echo "<font size='4' face='Arial' color = 'dimgrey'>";
					echo "NO STUDENTS FOUND<br>";
				}
		}
		if(isset($_GET["actionn4"])){
				echo "<br>";
				$srch = $_GET["srch"];
				$std_id = $_GET["stdid"]; 
				if($srch == "id"){
					$q = "update enrollment_history 
								set enrolled = 0 where student_id ='".$std_id."'";
				}
				else if($srch == "name"){
					$q = " update enrollment_history 
								set enrolled = 0 where name ='".$std_id."'";	
				}
				$query_id = oci_parse($con, $q);
				$r = oci_execute($query_id); 
				if($r){
					echo "<font size='5' face='Arial' color = 'dimgrey'>";
					echo "<br>&nbspSTUDENT HAS BEEN SUCCESSFULLY REMOVED FROM CLASS";
				}
				else{
					echo '<script>alert("ERROR :: STUDENT COULD NOT BE REMOVED")</script>';
				}
		}
		
?>
</html>