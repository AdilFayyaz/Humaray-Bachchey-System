<!DOCTYPE HTML>
<html>
	<head>
	<meta charset ="UTF-8">
	<title>Humaray Bachchay NGO</title>
	<link href="layout.css" rel='stylesheet' type='text/css'>
	</head>
	<body>
	<nav id="navigation-bar" style="z-index: 9;">
		<img id="logo" src="logo.png">
		<span class="navbar-text text" style= "margin-top: 30px;"> HUMARAY BACHCHAY  </span>
		<a href="Home.html"><p class="impact">Get in Touch</p></a>
		<div class="dropdown">
			<p class="impact">Parents/Guardians</p>
			<div class="dropdown-content">
			<a href="Std_Admission.php">Student Admission Form</a>
			<a href="Std_Acc_Form.php">Student Accompanying Form</a>
			<a href="Assignment_Form.php">Class Assignment Form</a>
			<a href="available_courses.php">Available Courses</a>
			<a href="Update_Info.php">Update Information</a>
			</div>
		</div> 
		<a href="Student.html"><p class="impact">Students</p></a>
		<div class="dropdown">
			<p class="impact">Staff</p>
			<div class="dropdown-content">
			<a href="Reports.php">Reports</a>
			<a href="student.php">Students Per Class</a>
			<a href="edit.php">Edit Sudents</a>
			</div>
		</div>
		<a href="Home.html"><p class="impact">About</p></a>
		<a href="Home.html"><p class="impact">Home</p></a>
	</nav>
	<br><br><br><br><br><br><br><br><br>

	<form action="" method="post">
	<div class="form-style-10">

	<h1>Student Accompanying  Form<span>Please Enter The Following Information</span></h1>

	<div ><p class="monospace"><b>Students Information</b></p></div>
    <div class="inner-wrap">
	
		<table width="100%">
			<tr>
				<td>
					<label>Name <input type="text" name="std_name" /></label>
					<label>ID<input type="text" name="std_id" required /></p></label>
					<label>Class<input type="text" name="std_class" /></p></label>
				</td>
			</tr>
		</table>
    </div>

    <div><p class="monospace"><b>Accompanying Guardian Information</b></p></div>
    <div class="inner-wrap">
	<table width="100%">
	<tr>
		<td>
       			<label>Name <input type="text" name="g_name" /></label>
        		<label>ID <input type="text" name="g_id" required /></label>
		</td>
		
	</tr>
	<table width="50%">
	<tr>	
        <td>
			
			<label>Pregnant <p class="monospace"> YES </p></label>
			<input type="radio" id="yes" name="preg" value="1" />
		</td>
		<td>
			<label><p class="monospace"> NO </p></label>
			<input type="radio" id="no" name="preg" value="0" />
		</td>

	<tr>
	</table>
	
	<tr>
		<td><br>
				<label>Reason for Parents Absence:<p class="monospace"> </p></label>
				<input type="text" name="reason" required/>
			
		</td>
	</tr>
	</table>
    </div>


    <div class="button-section">
     <input type="submit" name="enter_acc" value="Submit Form"/>
    </div>
	</form>
	</div>
	<script>
		window.onscroll = function() {scrollFunction()};

		function scrollFunction() {
		  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
			document.getElementById("navigation-bar").style.padding = "0px 10px";
			document.getElementById("logo").style.height = "120px";
			document.getElementById("logo").style.width = "110px";
			document.getElementById("logo").style.marginTop = "0px";
		  } else {
			document.getElementById("navigation-bar").style.padding = "40px 10px";
			document.getElementById("logo").style.height = "190px";
			document.getElementById("logo").style.width = "180px";
			document.getElementById("logo").style.marginTop = "-35px";
		  }
		}
	</script>
	<?php  
	   $db_sid = 
	   "(DESCRIPTION =
		(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
		(CONNECT_DATA =
		  (SERVER = DEDICATED)
		  (SERVICE_NAME = orcl)
		)
	  )";            
	   $db_user = "scott";   // Oracle username e.g "scott"
	   $db_pass = "1234";    // Password for user e.g "1234"
	   $con = oci_connect($db_user,$db_pass,$db_sid); 
		if($con){
			//Student Information was entered. 
			if(isset($_POST["enter_acc"]))
			{
				if(isset($_POST["std_id"]) && isset($_POST["g_id"]) && isset($_POST["reason"]) )
				{
					$std_id = $_POST["std_id"];
					$g_id = $_POST["g_id"];
					$q1 = "select * from responsible_for where Student_ID = '".$std_id."'" ;
					$query_id1 = oci_parse($con, $q1);
					$runselect1 = oci_execute($query_id1);

					$s_arr1= oci_fetch_array($query_id1, OCI_BOTH+OCI_RETURN_NULLS);
		
					if($s_arr1[0] != $std_id)
					{
						echo "<p style='text-align:center;' > RECORD NOT INSERTED.</p>" ;
						echo "<p style='text-align:center;' > Enter a valid Student ID. </p>" ;

						$q2 = "select * from responsible_for where Guardian_ID = '".$g_id."'";
						$query_id2 = oci_parse($con, $q2);
						$runselect2 = oci_execute($query_id2);
						$s_arr2= oci_fetch_array($query_id2, OCI_BOTH+OCI_RETURN_NULLS);
						
							if($s_arr2[0] != $g_id)
							{
								echo "<p style='text-align:center;' > Enter a valid Guardian ID. </p>" ;
								exit() ;
							
							}
						
					}
					else
					{
						$q4 = "select * from responsible_for where Guardian_ID = '".$g_id."'";
						$query_id4 = oci_parse($con, $q4);
						$runselect4 = oci_execute($query_id4);
						$s_arr4= oci_fetch_array($query_id4, OCI_BOTH+OCI_RETURN_NULLS);

						
							if($s_arr4[1] != $g_id)
							{	
								echo "<p style='text-align:center;' > RECORD NOT INSERTED.</p>" ;
								echo "<p style='text-align:center;' > Enter a valid Guardian ID. </p>" ;
								exit() ;
							
							}	
						
						
					}
						
						
					$q3 = "select * from responsible_for where Guardian_ID = '".$g_id."' and Student_ID = '".$std_id."' ";
					$query_id3 = oci_parse($con, $q3);
					$runselect3 = oci_execute($query_id3);
					$s_arr3= oci_fetch_array($query_id3, OCI_BOTH+OCI_RETURN_NULLS);
					
					
					if($s_arr3[0] != $std_id && $s_arr3[1] != $g_id)
					{
							echo "<p style='text-align:center;' > RECORD NOT INSERTED.</p>" ;
							echo "<p style='text-align:center;' >You are not the Guardian of this Student. Please Enter your own child ID </p>" ;
							exit() ;
					
					}
					else if ($s_arr3[3] == 0)
					{
						echo "<p style='text-align:center;' > RECORD NOT INSERTED.</p>" ;
						echo "<p style='text-align:center;' > You are not the current Guardian of this Student </p>" ;
						exit() ;
					}
					
					
					$std_name=$_POST["std_name"];
					$std_class = $_POST["std_class"];
					$preg = $_POST["preg"] ;
					$reason = $_POST["reason"];

					$q="insert into Student_Accompany_Form(Student_ID,Guardian_ID,Date_Of_Visit,Pregnant,Reason)
					values('".$std_id."', '".$g_id."',
					TO_DATE('".date("d/m/yy")."','dd/mm/yyyy'), ".$preg.", '".$reason."' )" ;

					$query_id = oci_parse($con, $q);
					$runselect = oci_execute($query_id);		
					
				}
					
			}
		}
		else{
			echo "RECORD NOT INSERTED";
			$e = oci_error($query_id);  
			echo $e['message'];	
		}
	?>
</html>