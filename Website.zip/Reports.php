<!DOCTYPE HTML>
<html>
	<head>
	<meta charset ="UTF-8">
	<title>Humaray Bachchay NGO</title>
	<link href="layout.css" rel='stylesheet' type='text/css'>
	</head>
	<style>
	  .required:after {
		content:" *";
		color: red;
	  }
	  .sidenav {
	  height: 70%;
	  width: 20%;
	  position: fixed;
	  z-index: 1;
	  top: 20%;
	  left: 75%;
	  background-color: thistle;
	  overflow-x: hidden;
	  padding-top: 20px;
	  padding-left: 20px;
	  padding-right: 15px;
	   box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.3), 0 5px 5px 0 rgba(0, 0, 0, 0.5);
	}
	</style>
	<body>
	<nav id="navigation-bar" style="z-index: 9;">
		<img id="logo" src="logo.png">
		<span class="navbar-text text" style= "margin-top: 30px;"> HUMARAY BACHCHAY  </span>
		<a href="Home.html"><p class="impact">Get in Touch</p></a>
		<div class="dropdown">
			<p class="impact">Parents/Guardians</p>
			<div class="dropdown-content">
			<a href="Std_Admission.php">Student Admission Form</a>
			<a href="Std_Acc_Form.php">Student Accompanying Form</a>
			<a href="Assignment_Form.php">Class Assignment Form</a>
			<a href="available_courses.php">Available Courses</a>
			<a href="Update_Info.php">Update Information</a>
			</div>
		</div> 
		<a href="Student.html"><p class="impact">Students</p></a>
		<div class="dropdown">
			<p class="impact">Staff</p>
			<div class="dropdown-content">
			<a href="Reports.php">Reports</a>
			<a href="student.php">Students Per Class</a>
			<a href="edit.php">Edit Sudents</a>
			</div>
		</div>
		<a href="Home.html"><p class="impact">About</p></a>
		<a href="Home.html"><p class="impact">Home</p></a>
	</nav>
	<br><br><br><br><br><br><br><br><br>
	</body>
	<form action="" method="POST" >
	<div class="form-style-10">
	<h1>Report 1: &nbsp&nbsp&nbsp <span>Enter the Class to see all students currently enrolled in it</span></h1>
        <div class="inner-wrap">
			<table>
			<tr>
			<label>Enter Class <input type="text" name="classchosen" /></label>
			</tr>
			</table>
		</div>
	</div>
	<div class="button-section" align=center>
     <input type="submit" name="report1" value="Search"/>
    </div>
	</form>
	<?php
	if(isset($_POST["report1"])){
			$classchosen = $_POST["classchosen"];
				$db_sid =   "(DESCRIPTION =
				(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
				(CONNECT_DATA =
				  (SERVER = DEDICATED)
				  (SERVICE_NAME = orcl)
				)
			  )";
			$db_user = "scott";   // Oracle username e.g "scott"
			$db_pass = "1234";    // Password for user e.g "1234"
			$con = oci_connect($db_user,$db_pass,$db_sid); 
			if($con) 
				{ } 
			else 
				{ die('Could not connect to Oracle: '); } 
			$q= "select s.Student_ID, s.Name, s.Gender, round(months_between(sysdate, s.dob)/12,2), e.section_id, e.enrollment_date from Student s, Enrollment_History e
					where e.Student_ID = s.Student_ID and e.enrolled = 1 and e.class_id= '".$classchosen."'";
				$query_id = oci_parse($con, $q);
				$runselect = oci_execute($query_id);
				echo "<br>";
				
				while($arr= oci_fetch_array($query_id, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "STUDENT ID:&nbsp&nbsp";
					echo $arr[0];
					echo "&nbsp&nbsp&nbsp&nbspNAME:&nbsp&nbsp";
					echo $arr[1];
					echo "&nbsp&nbsp&nbsp&nbspGENDER:&nbsp&nbsp";
					echo $arr[2];
					echo "&nbsp&nbsp&nbsp&nbspAGE:&nbsp&nbsp";
					echo $arr[3];
					echo "&nbsp&nbsp&nbsp&nbspSECTION:&nbsp&nbsp";
					echo $arr[4];
					echo "&nbsp&nbsp&nbsp&nbspENROLLMENT DATE:&nbsp&nbsp";
					echo $arr[5];
					echo "<br>";
				}
	}
	?>
	<br>
	<hr>
	<br>
	<form action="" method="POST" >
	<div class="form-style-10">
	<h1>Report 2: &nbsp&nbsp&nbsp <span>Enter Class to view general statistics of it</span></h1>
    <div><p class="monospace"><b>List Of Classes</b></p></div>
        <div class="inner-wrap">
			<table>
			<tr>
			<label>Enter Class <input type="text" name="classchosen" /></label>
			</tr>
			</table>
		</div>
	</div>
	<div class="button-section" align=center>
     <input type="submit" name="report2" value="Search"/>
    </div>
	</form>
	<?php
	if(isset($_POST["report2"])){
		$classchosen = $_POST["classchosen"];
		$db_sid =  "(DESCRIPTION =
		(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
		(CONNECT_DATA =
		  (SERVER = DEDICATED)
		  (SERVICE_NAME = orcl)
		)
	  )";
		$db_user = "scott";   // Oracle username e.g "scott"
		$db_pass = "1234";    // Password for user e.g "1234"
		$con = oci_connect($db_user,$db_pass,$db_sid); 
		if($con) 
				{ } 
		else 
			{ die('Could not connect to Oracle: '); } 
		$qr2 = "select count(case when UPPER(gender) = 'M' THEN 1 END) Male,
				count(case when UPPER(gender) = 'F' THEN 1 END) Female,
				count(s.student_id) as total from student s, enrollment_history h
				where s.student_id = h.student_id and h.enrolled = 1 and h.class_id = '".$classchosen."'";
		$query_idr2 = oci_parse($con, $qr2);
		$runselect2 = oci_execute($query_idr2);
		echo "<br>";
				
		while($arr2= oci_fetch_array($query_idr2, OCI_BOTH+OCI_RETURN_NULLS)){
				echo "MALE STUDENTS: ".$arr2[0];
				echo "<br>FEMALE STUDENTS: ".$arr2[1];
				echo "<br>TOTAL STUDENTS: ".$arr2[2];
		}
	}
	?>
	<br>
	<hr>
	<br>
	<form action="" method="POST" >
	<div class="form-style-10">
	<h1>Report 3: &nbsp&nbsp&nbsp <span>Enter Search Information in One of the Following Boxes</span></h1>
    <div><p class="monospace"><b>List Of Dormant Students</b></p></div>
        <div class="inner-wrap">
			<table>
			<tr>
			<label>Enter Months <input type="text" name="MONTHS" /></label>
			<label>Enter Years <input type="text" name="YEARS" /></label>
			</tr>
			</table>
		</div>
	</div>
	<div class="button-section" align=center>
     <input type="submit" name="Display" value="Search"/>
    </div>
	</form>
	<?php
	if(isset($_POST["Display"])){
		echo "<br>"; 
		echo "List of the Dormant Students ";
		$months = $_POST["MONTHS"];
		$years = $_POST["YEARS"];
		$db_sid= "(DESCRIPTION =
		(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
		(CONNECT_DATA =
		  (SERVER = DEDICATED)
		  (SERVICE_NAME = orcl)
		)
	  )";
		$db_user = "scott";   // Oracle username e.g "scott"
		$db_pass = "1234";    // Password for user e.g "1234"
		$con2 = oci_connect($db_user,$db_pass,$db_sid); 
		if($con2) 
			{ } 
		else 
			{ die('Could not connect to Oracle '); }   
		$get_date = date("d/m/Y");
		$space = "		";
		$q = "Alter session set nls_date_format='dd/mm/yyyy'";
		$query_id = oci_parse($con2, $q); 		
		$r = oci_execute($query_id); 
		if($months > 0){
				$q2 = "select * FROM ENROLLMENT_HISTORY WHERE MONTHS_BETWEEN(TO_DATE('".$get_date."' , 'dd/mm/yy') ,Enrollment_Date) >".$months ;
				$query_id2 = oci_parse($con2, $q2); 		
				$r2 = oci_execute($query_id2);
				$row = oci_fetch_array($query_id2);	
				echo "<br>";
				while($row = oci_fetch_array($query_id2, OCI_BOTH+OCI_RETURN_NULLS))  {				
						if($r2){
									echo "<b>Student ID:</b>" .$row['STUDENT_ID'], $space , "<b>Course ID:</b>".$row['COURSE_ID'] ,
									$space, "<b>Class ID:</b>".$row['CLASS_ID'], $space,"<b>Section ID:</b>".$row['SECTION_ID'], $space,"<b>Challan No: </b>".$row['FEE_CHALLAN'],
									$space,"<b>Enrollment Date:</b>".$row['ENROLLMENT_DATE']."<br>";}
					}
			}
		
		else if ($years > 0){
			$q3 = "select * FROM ENROLLMENT_HISTORY WHERE MONTHS_BETWEEN('".$get_date."',Enrollment_Date) / 12 >".$years ;
				$query_id3 = oci_parse($con2, $q3); 		
				$r3 = oci_execute($query_id3);
				$row1 = oci_fetch_array($query_id3);	
				echo "<br>";
				while($row1 = oci_fetch_array($query_id3, OCI_BOTH+OCI_RETURN_NULLS))  {				
						if($r3){
							echo "<b>Student ID:</b>" .$row1['STUDENT_ID'], $space , "<b>Course ID:</b>".$row1['COURSE_ID'] ,
									$space, "<b>Class ID:</b>".$row1['CLASS_ID'], $space,"<b>Section ID:</b>".$row1['SECTION_ID'], $space,"<b>Challan No: </b>".$row1['FEE_CHALLAN'],
									$space,"<b>Enrollment Date:</b>".$row1['ENROLLMENT_DATE']."<br>";}		
					}
		}
		else 
		{
				echo '<script> alert("Error In Search") </script>';
		}
	}
	  ?>
	  
	<br>
	<hr>
	<br>
	<form action="" method="POST" >
	<div class="form-style-10">
	<h1>Report 4: &nbsp&nbsp&nbsp <span>Enter Search Information in One of the Following Boxes</span></h1>
    <div><p class="monospace"><b>All Info Of Given Student</b></p></div>
        <div class="inner-wrap">
			<table>
			<tr>
			<label>Student ID <input type="text" name="std_id" /></label>
			<label>Student Name <input type="text" name="std_name" /></label>
			</tr>
			</table>
		</div>
	</div>
	<div class="button-section" align=center>
     <input type="submit" name="report4" value="Search"/>
    </div>
	</form>
	<?php
		$db_sid= "(DESCRIPTION =
		(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
		(CONNECT_DATA =
		  (SERVER = DEDICATED)
		  (SERVICE_NAME = orcl)
		)
	  )";
		$db_user = "scott";   // Oracle username e.g "scott"
		$db_pass = "1234";    // Password for user e.g "1234"
		$con = oci_connect($db_user,$db_pass,$db_sid); 
		if($con) 
			{ } 
		else 
			{ die('Could not connect to Oracle '); 
			$e = oci_error($query_id);  
			echo $e['message'];	
		}
		if(isset($_POST["report4"])){
			if(!empty($_POST["std_id"])){
				$qm="Select m.F_Name as Mother_Name,m.Mother_ID as Mother_ID from Mother m, M_CHILD_OF mc
					where mc.STUDENT_ID = '".$_POST["std_id"]."' and 
					mc.MOTHER_ID=m.Mother_ID and mc.CURRENT_=1";
				$qrym=oci_parse($con,$qm);
				$runm= oci_execute($qrym);	
				
				$qf="Select m.Father_Name as Father_Name,m.Father_ID as Father_ID  from Father m, F_CHILD_OF mc
				where mc.STUDENT_ID = '".$_POST["std_id"]."' and mc.Father_ID=m.Father_ID and mc.CURRENT_=1";
				$qryf=oci_parse($con,$qf);
				$runf= oci_execute($qryf);	
				
				$qg="Select G.Name as Guardian_Name, G.Guardian_ID as Guardian_ID from Guardian G, Responsible_For R, Student S
				where S.Student_ID='".$_POST["std_id"]."' and S.STUDENT_ID=R.Student_ID and R.Guardian_ID=G.Guardian_ID and R.CURRENT_=1";
				$qryg=oci_parse($con,$qg);
				$rung= oci_execute($qryg);
				
				$qs="(select S1.Name ,S1.Student_ID from M_CHILD_OF
					left outer join Student S1
					on S1.STUDENT_ID = M_CHILD_OF.STUDENT_ID
					where M_CHILD_OF.Mother_ID = (
						select M_CHILD_OF.Mother_ID from M_CHILD_OF,Student S2
						where S2.Student_ID='".$_POST["std_id"]."' and
						 M_CHILD_OF.STUDENT_ID=S2.STUDENT_ID and
						 M_CHILD_OF.CURRENT_=1
					) and M_CHILD_OF.CURRENT_=1 and  S1.STUDENT_ID <> '".$_POST["std_id"]."'
				)
				intersect
				(select S3.Name, S3.STUDENT_ID from F_CHILD_OF
					left outer join Student S3
					on S3.STUDENT_ID=F_CHILD_OF.STUDENT_ID
					where F_CHILD_OF.FATHER_ID= (
						select F_CHILD_OF.Father_ID from F_CHILD_OF,Student S4
						where S4.Student_ID='".$_POST["std_id"]."' and
						 F_CHILD_OF.STUDENT_ID=S4.STUDENT_ID and
						 F_CHILD_OF.CURRENT_=1
					)and F_CHILD_OF.CURRENT_=1 and S3.STUDENT_ID <> '".$_POST["std_id"]."'
				)";
				$qrys=oci_parse($con,$qs);
				$runs= oci_execute($qrys);
				
				$qc="select s.name ,e.course_id, c.course_title, e.enrollment_date from	
				Student s, Enrollment_History e, Course c 
				where s.student_Id='".$_POST["std_id"]."' and s.STUDENT_ID=e.Student_ID
					and e.course_id=c.course_id";
				$qryc=oci_parse($con,$qc);
				$runc= oci_execute($qryc);
				/*Echo Mother Info:*/
				echo "<br><b>Mother Information: </b><br>";
				while($arr_m= oci_fetch_array($qrym, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Mother Name: ".$arr_m[0]." MOTHER_ID: ".$arr_m[1]." " ;
				}
				echo "<br><b> Father Information: </b><br>";
				while($arr_f= oci_fetch_array($qryf, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Father Name:".$arr_f[0]." FATHER_ID: ".$arr_f[1]." " ;
				}
				echo "<br><b>Guardian Information: </b><br>";
				while($arr_g= oci_fetch_array($qryg, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Guardian Name:".$arr_g[0]." GUARDIAN_ID: ".$arr_g[1]." " ;
				}
				echo "<br><b>Siblings: </b><br>";
				while($arr_s= oci_fetch_array($qrys, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student Name:".$arr_s[0]." STUDENT_ID: ".$arr_s[1]." " ;
					echo "<br>";
				}
				echo "<br><b>Class History: </b><br>";
				while($arr_c= oci_fetch_array($qryc, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student Name:".$arr_c[0]." COURSE_ID: ".$arr_c[1]." Course Title: ".$arr_c[2]." Course Date: ".$arr_c[3]." " ;
					echo "<br>";
				}	
			}
			else if(!empty($_POST["std_name"])){
				$qm="Select m.F_Name as Mother_Name,m.Mother_ID as Mother_ID from Mother m, M_CHILD_OF mc
					where mc.MOTHER_ID=m.Mother_ID and mc.CURRENT_=1 and mc.STUDENT_ID=(
						Select s.STUDENT_ID from Student s where 
						s.Name = '".$_POST["std_name"]."'
					)";
				$qrym=oci_parse($con,$qm);
				$runm= oci_execute($qrym);	
				
				$qf="Select m.Father_Name as Father_Name,m.Father_ID as Father_ID from Father m, F_CHILD_OF mc
					where mc.Father_ID=m.Father_ID and mc.CURRENT_=1 and mc.STUDENT_ID=(
						Select s.STUDENT_ID from Student s where 
						s.Name = '".$_POST["std_name"]."'
					)";
				$qryf=oci_parse($con,$qf);
				$runf= oci_execute($qryf);	
				
				$qg="Select G.Name as Guardian_Name, G.Guardian_ID as Guardian_ID from Guardian G, Responsible_For R, Student S
				where S.Name='".$_POST["std_name"]."' and S.STUDENT_ID=R.Student_ID and R.Guardian_ID=G.Guardian_ID and R.CURRENT_=1";
				$qryg=oci_parse($con,$qg);
				$rung= oci_execute($qryg);
				
				$qs="(select S1.Name ,S1.Student_ID from M_CHILD_OF
					left outer join Student S1
					on S1.STUDENT_ID = M_CHILD_OF.STUDENT_ID
					where M_CHILD_OF.Mother_ID = (
						select M_CHILD_OF.Mother_ID from M_CHILD_OF,Student S2
						where S2.name='".$_POST["std_name"]."' and
						 M_CHILD_OF.STUDENT_ID=S2.STUDENT_ID and
						 M_CHILD_OF.CURRENT_=1
					) and M_CHILD_OF.CURRENT_=1 and  S1.name <> '".$_POST["std_name"]."'
				)
				intersect
				(select S3.Name, S3.STUDENT_ID from F_CHILD_OF
					left outer join Student S3
					on S3.STUDENT_ID=F_CHILD_OF.STUDENT_ID
					where F_CHILD_OF.FATHER_ID= (
						select F_CHILD_OF.Father_ID from F_CHILD_OF,Student S4
						where S4.name='".$_POST["std_name"]."' and
						 F_CHILD_OF.STUDENT_ID=S4.STUDENT_ID and
						 F_CHILD_OF.CURRENT_=1
					)and F_CHILD_OF.CURRENT_=1 and  S3.name <> '".$_POST["std_name"]."'
				)";
				$qrys=oci_parse($con,$qs);
				$runs= oci_execute($qrys);
				
				$qc="select s.name ,e.course_id, c.course_title, e.enrollment_date from	
				Student s, Enrollment_History e, Course c 
				where s.name='".$_POST["std_name"]."' and s.STUDENT_ID=e.Student_ID
					and e.course_id=c.course_id";
				$qryc=oci_parse($con,$qc);
				$runc= oci_execute($qryc);
				/*Echo Mother Info:*/
				echo "<br><b>Mother Information: </b><br>";
				while($arr_m= oci_fetch_array($qrym, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Mother Name: ".$arr_m[0]." MOTHER_ID: ".$arr_m[1]." " ;
				}
				echo "<br><b> Father Information: </b><br>";
				while($arr_f= oci_fetch_array($qryf, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Father Name:".$arr_f[0]." FATHER_ID: ".$arr_f[1]." " ;
				}
				echo "<br><b>Guardian Information: </b><br>";
				while($arr_g= oci_fetch_array($qryg, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Guardian Name:".$arr_g[0]." GUARDIAN_ID: ".$arr_g[1]." " ;
				}
				echo "<br><b>Siblings: </b><br>";
				while($arr_s= oci_fetch_array($qrys, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student Name:".$arr_s[0]." STUDENT_ID: ".$arr_s[1]." " ;
					echo "<br>";
				}
				echo "<br><b>Class History: </b><br>";
				while($arr_c= oci_fetch_array($qryc, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student Name:".$arr_c[0]." COURSE_ID: ".$arr_c[1]." Course Title: ".$arr_c[2]." Course Date: ".$arr_c[3]." " ;
					echo "<br>";
				}	
			}
			else{
				echo '<script> alert("Error In Search") </script>';
			}
		}
	?>
	
	<br>
	<hr>
	<br>
	<form action="" method="POST" >
	<div class="form-style-10">
	<h1>Report 5: &nbsp&nbsp&nbsp <span>Enter Search Information in One of the Following Boxes</span></h1>
    <div><p class="monospace"><b>All Info of Given Parent</b></p></div>
        <div class="inner-wrap">
			<table>
			<tr>
			<label>Mother ID <input type="text" name="m_id" /></label>
			<label>Mother Name <input type="text" name="m_name" /></label>
			<label>Father ID <input type="text" name="f_id" /></label>
			<label>Father Name <input type="text" name="f_name" /></label>
			</tr>
			</table>
		</div>
	</div>
	<div class="button-section" align=center>
     <input type="submit" name="report5" value="Search"/>
    </div>
	</form>
	<?php
		$db_sid= "(DESCRIPTION =
		(ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-MR66B9O)(PORT = 1521))
		(CONNECT_DATA =
		  (SERVER = DEDICATED)
		  (SERVICE_NAME = orcl)
		)
	  )";
		$db_user = "scott";   // Oracle username e.g "scott"
		$db_pass = "1234";    // Password for user e.g "1234"
		$con = oci_connect($db_user,$db_pass,$db_sid); 
		if($con) 
			{ } 
		else 
			{ die('Could not connect to Oracle '); 
			$e = oci_error($query_id);  
			echo $e['message'];
		}
		if(isset($_POST["report5"])){
			if(!empty($_POST["m_id"])){
				$q="select M_CHILD_OF.Student_ID, S2.name, E.Class_ID, G.Name as Guardian_Name,G.Guardian_ID  from M_CHILD_OF,
				Student S2, Mother M,ENROLLMENT_HISTORY E, Responsible_For R, Guardian G
				where M.mother_id='".$_POST["m_id"]."' and
				 M_CHILD_OF.STUDENT_ID=S2.STUDENT_ID and
				 M_CHILD_OF.CURRENT_=1 and M.Mother_Id= M_CHILD_OF.Mother_Id
				 and E.Student_ID=S2.STUDENT_ID and E.enrolled=1 and 
				 R.STUDENT_ID=S2.STUDENT_ID and G.Guardian_ID=R.Guardian_ID
				 and R.Current_=1";
				// echo $q;
				 $qry=oci_parse($con,$q);
				 $run= oci_execute($qry);
				while($arr= oci_fetch_array($qry, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student ID: ".$arr[0]." Student Name: ".$arr[1]."
					Class ID: ".$arr[2]." Guardian Name: ".$arr[3]." Guardian ID:
					".$arr[4]." " ;
					echo "<br>";
				}
			 
			}
			else if(!empty($_POST["m_name"])){
				$q="select M_CHILD_OF.Student_ID, S2.name, E.Class_ID, G.Name as Guardian_Name,G.Guardian_ID  from M_CHILD_OF,
				Student S2, Mother M,ENROLLMENT_HISTORY E, Responsible_For R, Guardian G
				where M.F_name='".$_POST["m_name"]."' and
				M_CHILD_OF.STUDENT_ID=S2.STUDENT_ID and
				M_CHILD_OF.CURRENT_=1 and M.Mother_Id= M_CHILD_OF.Mother_Id
				and E.Student_ID=S2.STUDENT_ID and E.enrolled=1 and 
				R.STUDENT_ID=S2.STUDENT_ID and G.Guardian_ID=R.Guardian_ID
				and R.Current_=1";
				 $qry=oci_parse($con,$q);
				 $run= oci_execute($qry);
				while($arr= oci_fetch_array($qry, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student ID: ".$arr[0]." Student Name: ".$arr[1]."
					Class ID: ".$arr[2]." Guardian Name: ".$arr[3]." Guardian ID:
					".$arr[4]." " ;
					echo "<br>";
				}
			}
			else if(!empty($_POST["f_id"])){
				$q="select F_CHILD_OF.Student_ID, S2.name, E.Class_ID, G.Name as Guardian_Name,G.Guardian_ID  from F_CHILD_OF,
				Student S2, Father F,ENROLLMENT_HISTORY E, Responsible_For R, Guardian G
				where F.FATHER_ID='".$_POST["f_id"]."' and
				 F_CHILD_OF.STUDENT_ID=S2.STUDENT_ID and
				 F_CHILD_OF.CURRENT_=1 and F.Father_Id= F_CHILD_OF.Father_Id
				 and E.Student_ID=S2.STUDENT_ID and E.enrolled=1 and 
				 R.STUDENT_ID=S2.STUDENT_ID and G.Guardian_ID=R.Guardian_ID
				 and R.Current_=1";
				 $qry=oci_parse($con,$q);
				 $run= oci_execute($qry);
				while($arr= oci_fetch_array($qry, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student ID: ".$arr[0]." Student Name: ".$arr[1]."
					Class ID: ".$arr[2]." Guardian Name: ".$arr[3]." Guardian ID:
					".$arr[4]." " ;
					echo "<br>";
				}
			}
			else if(!empty($_POST["f_name"])){
				$q="select F_CHILD_OF.Student_ID, S2.name, E.Class_ID, G.Name as Guardian_Name,G.Guardian_ID  from F_CHILD_OF,
				Student S2, Father F,ENROLLMENT_HISTORY E, Responsible_For R, Guardian G
				where F.Father_Name='".$_POST["f_name"]."' and
				 F_CHILD_OF.STUDENT_ID=S2.STUDENT_ID and
				 F_CHILD_OF.CURRENT_=1 and F.Father_Id= F_CHILD_OF.Father_Id
				 and E.Student_ID=S2.STUDENT_ID and E.enrolled=1 and 
				 R.STUDENT_ID=S2.STUDENT_ID and G.Guardian_ID=R.Guardian_ID
				 and R.Current_=1";
				 $qry=oci_parse($con,$q);
				 $run= oci_execute($qry);
				while($arr= oci_fetch_array($qry, OCI_BOTH+OCI_RETURN_NULLS)){
					echo "Student ID: ".$arr[0]." Student Name: ".$arr[1]."
					Class ID: ".$arr[2]." Guardian Name: ".$arr[3]." Guardian ID:
					".$arr[4]." " ;
					echo "<br>";
				}
			}
			else{
				echo '<script> alert("Error In Search") </script>';
			}
		}
	?>
	<br><br><br><br><br>
</html>